VEYROVA BD — Free Clothing Store Demo

Files:
- index.html: website structure
- style.css: responsive design
- script.js: product list, cart, search and WhatsApp order flow

How to use on GitHub Pages:
1. Open your GitHub repository.
2. Upload these 3 files to the repository root (same level as README).
3. Commit the changes to the main branch.
4. Open Settings > Pages, select Deploy from a branch, choose main and /(root), then Save.
5. Wait for deployment and open the published site.

Before taking orders:
- Open script.js and replace 8801XXXXXXXXX with your shop WhatsApp number, digits only (example format: 88017XXXXXXXX).
- Replace sample product names/prices with your real inventory.
- Product images are emoji placeholders; add your own product photos later.
- This is a front-end demo. Cart and order details are not stored in a database.
- bKash/Nagad shown in the form are manual-payment labels only. This does NOT implement automatic payment verification.
