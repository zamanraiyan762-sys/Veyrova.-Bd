const products = [
 {id:1,name:"Spider Hoodie",price:850,old:1200,discount:"29% OFF",tag:"New",emoji:"🧥",category:"Hoodie"},
 {id:2,name:"Brooklyn Oversize T-Shirt",price:450,old:650,discount:"31% OFF",tag:"New",emoji:"👕",category:"T-Shirt"},
 {id:3,name:"Check Shirt",price:650,old:900,discount:"28% OFF",tag:"Best Seller",emoji:"👔",category:"Shirt"},
 {id:4,name:"Cargo Pant",price:750,old:1100,discount:"32% OFF",tag:"New",emoji:"👖",category:"Pant"},
 {id:5,name:"Classic Black Cap",price:350,old:550,discount:"36% OFF",tag:"Hot",emoji:"🧢",category:"Accessories"}
];
let cart = [];
const money = n => "৳" + n.toLocaleString("en-US");
const productsEl = document.getElementById("products");
function renderProducts(list=products){
 productsEl.innerHTML = list.length ? list.map(p=>`<article class="product"><span class="tag">${p.tag}</span><div class="product-img"><span class="product-emoji">${p.emoji}</span></div><h3>${p.name}</h3><div class="price">${money(p.price)} <span class="old">${money(p.old)}</span> <span class="discount">${p.discount}</span></div><div class="rating">★★★★★ <small>(24)</small></div><button class="add-btn" onclick="addToCart(${p.id})">🛒 &nbsp; Add to Cart</button></article>`).join("") : '<p>কোনো প্রোডাক্ট পাওয়া যায়নি।</p>';
}
function addToCart(id){const found=cart.find(x=>x.id===id);if(found)found.qty++;else cart.push({...products.find(x=>x.id===id),qty:1});renderCart();openCart();}
function renderCart(){
 document.getElementById("cartCount").textContent=cart.reduce((s,x)=>s+x.qty,0);
 document.getElementById("cartTotal").textContent=money(cart.reduce((s,x)=>s+x.price*x.qty,0));
 const el=document.getElementById("cartItems");
 el.innerHTML=cart.length?cart.map(p=>`<div class="cart-item"><div class="mini">${p.emoji}</div><div class="details"><b>${p.name}</b><small>${money(p.price)}</small><div class="qty"><button onclick="changeQty(${p.id},-1)">−</button><span>${p.qty}</span><button onclick="changeQty(${p.id},1)">+</button></div></div><button onclick="removeItem(${p.id})" aria-label="Remove item" style="border:0;background:none;cursor:pointer">✕</button></div>`).join(""):'<p class="empty">এখনো কোনো প্রোডাক্ট যোগ করোনি।</p>';
}
function changeQty(id,n){const item=cart.find(x=>x.id===id);if(item)item.qty+=n;cart=cart.filter(x=>x.qty>0);renderCart();}
function removeItem(id){cart=cart.filter(x=>x.id!==id);renderCart();}
function openCart(){document.getElementById("cartPanel").classList.add("open");document.getElementById("overlay").classList.add("open");}
function closeCart(){document.getElementById("cartPanel").classList.remove("open");document.getElementById("overlay").classList.remove("open");}
document.getElementById("cartOpen").addEventListener("click",openCart);
document.getElementById("cartClose").addEventListener("click",closeCart);
document.getElementById("overlay").addEventListener("click",closeCart);
document.getElementById("searchInput").addEventListener("input",e=>{const q=e.target.value.toLowerCase();renderProducts(products.filter(p=>(p.name+" "+p.category).toLowerCase().includes(q)));});
document.getElementById("checkoutBtn").addEventListener("click",()=>{if(!cart.length){alert("আগে কার্টে প্রোডাক্ট যোগ করুন।");return;}closeCart();document.getElementById("orderDialog").showModal();});
document.getElementById("dialogClose").addEventListener("click",()=>document.getElementById("orderDialog").close());
document.getElementById("orderForm").addEventListener("submit",e=>{
 e.preventDefault();
 const data=new FormData(e.target);
 const lines=cart.map(p=>`${p.name} x${p.qty} = ${money(p.price*p.qty)}`).join("\n");
 const total=cart.reduce((s,p)=>s+p.price*p.qty,0);
 const msg=`নতুন অর্ডার - Veyrova BD\nনাম: ${data.get("name")}\nফোন: ${data.get("phone")}\nঠিকানা: ${data.get("address")}\nপেমেন্ট: ${data.get("payment")}\n\nপণ্য:\n${lines}\n\nমোট: ${money(total)}`;
 // Replace 8801XXXXXXXXX with the shop owner's WhatsApp number, digits only.
 const shopWhatsApp="8801XXXXXXXXX";
 if(shopWhatsApp.includes("X")){alert("প্রথমে script.js ফাইলে shopWhatsApp-এর জায়গায় তোমার WhatsApp নম্বর বসাও (যেমন 88017XXXXXXXX)।");return;}
 window.open(`https://wa.me/${shopWhatsApp}?text=${encodeURIComponent(msg)}`,"_blank");
});
renderProducts();renderCart();
